/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Db;
import java.sql.*;
/**
 *
 * @author D2A
 */
public class Koneksi {
    static final String JDBC_DRIVER = "com.mysql.jdbc.Driver";
    static final String DB_URL = "jdbc:mysql://127.0.0.1/test?autoReconnect=true&useSSL=false";
    static final String USER = "harkespan";
    static final String PASS = "rahasia123";
    
    static Connection conn;
    static Statement stmt;
    static ResultSet rs; 
    
   public void koneksidb(){
       try{
           Class.forName(JDBC_DRIVER);
           conn = DriverManager.getConnection(DB_URL, USER, PASS);
           stmt = conn.createStatement();
       }
       catch(Exception e){
           e.printStackTrace();
       }
   }
}
